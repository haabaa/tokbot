# CareTrust Room Watch

See chat history for full app.py content. This zip structure matches deployment layout.
